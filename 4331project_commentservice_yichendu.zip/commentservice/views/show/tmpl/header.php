<?php //if(!$data['is_login']){ ?>
<!--    <p class="log">-->
<!--        <a href="index.php?c=user&a=login">User Login</a>-->
<!--        <a href="index.php?c=customer&a=login">Customer Login</a>-->
<!--    </p>-->
<?php //} else {?>
<!--    <p class="log">-->
<!--        <a href="index.php?c=user&a=logout">Log Out</a>-->
<!--    </p>-->
<?php //} ?>

<a href="index.php?c=statistic&a=index">show statistic</a>
