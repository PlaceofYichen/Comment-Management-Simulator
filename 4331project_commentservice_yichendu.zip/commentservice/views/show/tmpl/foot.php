<script src="<?=showRoot;?>js/jquery.min.js"></script>
<script src="<?=CommonRoot;?>/layer/layer.js"></script>
<script src="<?=CommonRoot;?>/common.js"></script>