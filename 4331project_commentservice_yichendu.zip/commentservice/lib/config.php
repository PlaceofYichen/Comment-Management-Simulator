<?php

header("Content-Type: text/html; charset=utf-8");
define('DB_HOST', '127.0.0.1');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', 'woshiADU123');
define('DB_DATABASE', 'commentservice');
define('DB_CHARSET', 'utf8');

define('SESSION_USER', 'user');
define('SESSION_CUSTOMER', 'customer');

?>